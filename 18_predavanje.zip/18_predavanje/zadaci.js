var broj = 5;

if (broj % 2 == 0){
    console.log("Broj je paran")
} else {
    console.log("Broj je neparan.")
}