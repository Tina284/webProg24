/*for (let i = 0; i < 5; i++){
    console.log(i);
};
console.log(i);*/
/*
let broj = 4
while (broj <5){
    console.log("while", broj);
    broj++;
}
let broj2 = 4
do {
    console.log("do while", broj2);
    broj2++;
} while (broj2 < 5)
*/
//Zd 1. 
/*for (let i = 2; i <= 20; i += 2){
    console.log(i);
}*/

//Zd 2.
/*
let zbroj = 0
for (let i = 1; i <= 5; i++){
    zbroj += i;
}
console.log(zbroj);*/

//Zd 3.
/*const niz = ["HTML", "CSS", "JS"];
for (let i = 0; i<niz.length; i++){
    console.log(niz[i])
}*/

//Zd 4.
let rijec = "programiranje";
for (let i = 0; i < rijec.length; i++){
    console.log(rijec[i]);
}
