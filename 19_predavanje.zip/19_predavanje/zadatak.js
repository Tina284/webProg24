var broj = 31;

if (broj % 3 == 0 && broj % 5 == 0) {
    console.log("broj je djeljiv s 3 i 5.")
}
else {
    console.log("Broj nije djeljiv s 3 i 5.")
}
