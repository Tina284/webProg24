let N = 12117;
let niz = [N];

while (N >= 10) {
    let umnozak = 1;
    while (N > 0){
        umnozak *= N % 10;
        N = Math.floor(N / 10);
    }
    niz.push(umnozak);
    N = umnozak;
}

let posljednji = N;
let duljina = niz.length;

console.log("Posljednji član:", N);
console.log("Broj članova niza:", duljina);