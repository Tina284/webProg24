console.log("HELLO");










// Zadatak 1
var ime = "Ana";
var prezime = "Anić";
console.log(ime + " " + prezime);

// Zadatak 2
var prvi = 10;
var drugi = 3;

// Zadatak 3
var zbroj = prvi + drugi;
console.log("Zbroj brojeva je " + zbroj + ".");

// Zadatak 4
console.log("Prvi broj + drugi broj =", prvi + drugi);
console.log("Prvi broj - drugi broj =", prvi - drugi);
console.log("Prvi broj / drugi broj =", prvi / drugi);
console.log("Prvi broj * drugi broj =", prvi * drugi);
console.log("Prvi broj % drugi broj =", prvi % drugi);

// Zadatak 5
console.log("Prvi broj == drugi broj:", prvi == drugi);
console.log("Prvi broj != drugi broj:", prvi != drugi);
console.log("Prvi broj > drugi broj:", prvi > drugi);
console.log("Prvi broj >= drugi broj:", prvi >= drugi);
console.log("Prvi broj < drugi broj:", prvi < drugi);
console.log("Prvi broj <= drugi broj:", prvi <= drugi);

// Zadatak 6
console.log("true || false =", true || false);
console.log("true && false =", true && false);

// Zadatak 7
prvi += 2;
console.log("Vrijednost prve varijable nakon dodavanja 2:", prvi);
prvi -= 2;
console.log("Vrijednost prve varijable nakon oduzimanja 2:", prvi);
prvi *= 2;
console.log("Vrijednost prve varijable nakon množenja s 2:", prvi);
prvi /= 2;
console.log("Vrijednost prve varijable nakon dijeljenja s 2:", prvi);

